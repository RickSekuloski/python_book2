def only_even_num(list_item):
    return list_item % 2 == 0


# number list
number_list = [1, 2, 3, 4, 5, 6]

# filter function
print(list(filter(only_even_num, number_list)))


def filter_names(list_item):
    return 'om' in list_item


# number list
user_names = ['Tom', 'Jason', 'Anom', 'Shanon', 'Angelomaria']

# map function
print(list(filter(filter_names, user_names)))

