# even list
even_list = [2, 4, 6, 8]

# odd list
odd_list = [1, 3, 5, 7]

# zip function
print(list(zip(even_list, odd_list)))



# even tuple
even_tuple = (2, 4, 6, 8)

# odd tuple
odd_tuple = (1, 3, 5, 7)

# zip function
print(list(zip(even_tuple, odd_tuple)))

