def odd_numbers(list_item):
    return list_item - 1

# even list
even_list = [2, 4, 6, 8]

# map function
print(list(map(odd_numbers, even_list)))
print(even_list)


# another map example
def user_names(user_item):
    return user_item.upper()

# user list
user_list = ['andy', 'jason', 'tom']

# map function
print(list(map(user_names, user_list)))
