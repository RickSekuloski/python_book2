# first list
first_list = [2, 4, 6, 8]

# second list
second_list = []

for num in first_list:
    second_list.append(num)

print(second_list)

second_list2 = [num for num in first_list ]
print(second_list2)

# even list example 2
old_list = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
even_list = [num for num in old_list if num % 2 ==0]
print(even_list)

# list from 0 - 100

long_list = [num for num in range(0,100)]
print(long_list)


# even_list
even_list = [2, 4, 6, 8, 10]
# odd_list
odd_list = [num-1 for num in even_list]
print(odd_list)

# odd_list with items >= 3
odd_list1 = [num-1 for num in even_list if num >=3]
print(odd_list1)

# Set comprehension

# first set
first_set = {10, 12, 14, 16}

# second set
second_set = {}

second_set = {num for num in first_set}
print(second_set)

# long set
long_set = {num for num in range(0, 100)}
print(long_set)


# Dictionary Comprehension
my_dict1 = {
    'one': 1,
    'two': 2,
    'three': 3
}
my_dict2 = {key:value for key,value in my_dict1.items()}
print(my_dict2)
my_dict3 = {key:value+1 for key,value in my_dict1.items()}
print(my_dict3)
#if condition
my_dict4 = {key:value for key,value in my_dict1.items() if value%2==0}
print(my_dict4)

