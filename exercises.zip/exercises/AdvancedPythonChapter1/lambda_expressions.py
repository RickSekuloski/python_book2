# lambda expressions
num_list = [-1, 0, 1, 2, 3]
print(list(map(lambda item: item + 1, num_list)))


# the same could be achieved like this
def add_one(item):
    return item + 1


print(list(map(add_one, num_list)))

# reduce & lambda
from functools import reduce
print(reduce(lambda acc, item: acc + item , num_list, 0))