from functools import reduce


#1)	There will be a List of car names given.
# The given list (my_cars)
# will have all of its names written in lower letters.
my_cars = ['audi', 'bmw', 'holden', 'kia', 'tesla']
#a)	Capitalize all of the car names and print the list
def capitalize_fn(cars):
    return cars.upper()

print(list(map(capitalize_fn, my_cars)))
#b)	Capitalize all of the car names and print the list

def capitalize_fn1(cars):
    return cars.capitalize()

print(list(map(capitalize_fn1, my_cars)))

#2) Zip the following  lists into a list of tuples,
# but sort the numbers from lowest to highest for both of the list.
string_list = ['b', 'd', 'e', 'c', 'a']
num_list = [10, 7, 8, 9, 6]

print(list(zip(sorted(string_list), sorted(num_list))))


#3) Filter the following list called age_restrictions
# Make sure that all of the users above 18 (including 18) are filtered
age_restrictrions = [16, 22, 19, 18, 15, 33, 29]

def check_age(age):
    return age >= 18

print(list(filter(check_age, age_restrictrions)))


#4 Accumulate all of the numbers from two list
# using the reduce (num_1 and num_2). What is their total?

num_1 = [2, 4, 0, 8]
num_2 = [3, 6, 9, 1]

def accumulator(acc, item):
    return acc + item

print(reduce(accumulator, (num_1 + num_2), 0))

#5) Using lambda expressions create one line code
# that square the following list, this means  that each of the list
# items is raised to the power of two for example 3 to the power of 2 is 9:
numbers_list = [3, 9, 7]
# desired_list = [9, 81, 49]

desired_list = (list(map(lambda num: num**2, numbers_list)))
print(desired_list)

#6)This exercise is about finding the items that are repeated in the list.
# The repeated items should be stored in a new list

long_list = ['1', '2', '3', '4', '2', '5', '4', '7', '8', '6', '7']
# The output should be list like this:
# duplicates_only = ['2', '4', '7']

duplicates_only = list(set(num for num in long_list if long_list.count(num)>1))
print(duplicates_only)

#7 Using the list comprehension convert the duplicate_only list (which holds strings only)
# into integer list called duplicates_only_int

duplicates_only_int = list(int(num) for num in duplicates_only)
print(duplicates_only_int)