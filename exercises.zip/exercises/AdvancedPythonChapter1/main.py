def odd_numbers(even_list):
    odd_num = []
    for num in even_list:
        odd_num.append(num - 1)
    return odd_num


# even list
even_list = [2, 4, 6, 8]

print(odd_numbers(even_list))


# not pure function

def odd_numbers1(even_list):
    odd_num = []
    for num in even_list:
        odd_num.append(num - 1)
    return print(odd_num)


# even list
even_list1 = [2, 4, 6, 8]

odd_numbers1(even_list)

# not pure function example 2
odd_num2 = []


def odd_numbers2(even_list):
    for num in even_list:
        odd_num2.append(num - 1)
    return odd_num2


# even list
even_list2 = [2, 4, 6, 8]
# odd_num2 = [5]
print(odd_numbers2(even_list2))
