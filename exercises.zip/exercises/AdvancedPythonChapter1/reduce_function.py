from functools import reduce

# number list

num_list = [1, 2, 3, 4, 5]


def accumulator(acc, item):

    print(f"Acc: {acc}, item {item}")
    return acc + item


print(reduce(accumulator, num_list, 0))
