#test.py
import unittest
import main


class TestMainClass(unittest.TestCase):
    def setUp(self):
        print('This will run and set everything before each test')

    def test_multiply_main(self):
        param_x = 4
        test_result = main.multiply_by_7(param_x)
        self.assertEqual(test_result, 28)

    def test_multiply_main2(self):
        param_x = '4'
        test_result = main.multiply_by_7(param_x)
        self.assertEqual(test_result, 28)


    def test_multiply_main3(self):
        param_x = '4th'
        test_result = main.multiply_by_7(param_x)
        self.assertIsInstance(test_result, ValueError)

    def test_multiply_main4(self):
        ''' Test number 4 where we test when param_x is equal to None'''
        param_x = None
        test_result = main.multiply_by_7(param_x)
        self.assertEqual(test_result, 0)

    def tearDown(self):
        print('This will rafter all of the tests are completed')


unittest.main()

