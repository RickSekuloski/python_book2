#main.py
def multiply_by_7(x):
    try:
        if x!= None:
            return int(x) * 7
        else:
            return 0
    except ValueError as err:
        return err

