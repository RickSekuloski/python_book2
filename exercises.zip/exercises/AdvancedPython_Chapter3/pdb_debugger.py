import pdb
def calc(num1, num2, num3):
    # pdb.set_trace()
    return num1 + num2 + num3

# calc(1, 2, 'three')
calc(1, 2, 3)