# Generators
mylist = [0, 1, 2, 3, 4, 5, 6]
# print(mylist)

# Create our own generator

def our_generator(n):
    for i in range(n):
        yield i

# for item in our_generator(10):
#     print(item)
item = our_generator(10)
print(next(item))
print(next(item))
print(next(item))
print(next(item))


def our_generator1(n):
    for i in range(n):
        yield i


item1 = our_generator1(3)
print(next(item1))
print(next(item1))
print(next(item1))
# print(next(item1))


# fibonacci
def fibonacci_seq(n):
    a, b = 0, 1
    for _ in range(n):
        yield a
        a, b = b, a + b

fib_numbers = list(fibonacci_seq(11))
print(fib_numbers)
