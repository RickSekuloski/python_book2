# Decorators
def decorator_function(func):
    def wrapper_fn():
        print('*** What is your name? ***')
        func()
        print('*** Thank you! ***')
    return wrapper_fn


# simple fn
@decorator_function
def my_name():
    print('My name is Jason')

my_name()

# this is happening in the background
# comment the @decorator_function
# comment the my_name() before you test
# the two lines below
# a = decorator_function(my_name)
# print(a())



# example 2
def decorator_function1(func):
    def wrapper_fn(name):
        print('*** What is your name? ***')
        func(name)
        print('*** Thank you! ***')
    return wrapper_fn


# simple fn
@decorator_function1
def my_name1(name):
    print(f'My name is {name}')


my_name1('John Doe')

# example 3 *args and **kwargs
def decorator_function2(func):
    def wrapper_fn(*args, **kwargs):
        print('*** What is your name? ***')
        func(*args, **kwargs)
        print('*** Thank you! ***')
    return wrapper_fn


# simple fn
@decorator_function2
def my_name2(name, work='Programmer', lives='USA'):
    print(f'My name is {name}, {work}, {lives}')


my_name2('Jane Doe')