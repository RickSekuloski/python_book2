# Decorators

def print_hi():
    print(f'Hi there')


message = print_hi
print(message())


def print_m(funct_name):
    print(funct_name())


def message():
    return 'Message fn'


msg = print_m(message)
print(msg)


# HOC- Higher Order Function

def first():
    def second():
        return 'Hi'
    return second()

print(first())