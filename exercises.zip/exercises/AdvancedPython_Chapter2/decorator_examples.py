from random import randint
from time import sleep, time

def execution_time(func):
    def wrapper_fn(*args, **kwargs):
        t1 = time()
        func(*args, **kwargs)
        t2 = time()
        print(f'Finished in {t2 - t1}s')
    return wrapper_fn


@execution_time
def script_run():
    sleep(randint(1, 4))

script_run()


# example number 2

# Create an @loggedin decorator that will allow a function to execute if user has 'registered' is set to True:
user = {
    'name': 'James',
    'email': 'james@gmail.com',
    'registered': True,
}

def loggedin(func):
  def wrapper(*args, **kwargs):
      if args[0]['registered']:
          return func(*args, **kwargs)
  return wrapper

@loggedin
def welcome_message(user):
    print(f'Welcome Back User, You can start shopping')

welcome_message(user)