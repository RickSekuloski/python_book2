import re
my_text = 'Its sometimes her behaviour are contented.' \
          'Do listening am eagerness oh objection' \
          'collected.' \
          'Together sometimes feelings continue juvenile had off one.' \
          'Unknown may service subject her letters one bed. ' \
          'Child years noise ye in forty. Loud in this in both hold. ' \
          'My entrance me is ' \
          'disposal bachelor remember relation.'

result = re.search('juvenile', my_text)
print(result)
print(result.span())
print(result.start())
print(result.end())
print(result.group())

print(re.search('Juvenile', my_text))

# fullmatch
my_string1 = 'Hi there'
my_result = re.fullmatch('Hi there!', my_string1)
print(my_result)

# split
my_string2 = 'Hi there my friend'
my_result1 = re.split('i', my_string2)
print(my_result1)

# creating new pattern
my_pattern = re.compile('behaviour')
result2 = my_pattern.search(my_text)
print(result2.group())

# findall new pattern
my_pattern = re.compile('sometimes')
result3 = my_pattern.findall(my_text)
print(result3)

# Testing pattern from regex101
new_text = 'This is 4 real'
my_pattern1 = re.compile(r"([a-zA-Z]).([\d])")
result4 = my_pattern1.search(new_text)
print(result4.group())









