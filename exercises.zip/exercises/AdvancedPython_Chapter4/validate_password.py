import re
user_password = 'BulletProofpass12#'
my_pattern = re.compile(r"[a-zA-Z0-9#$&@]{10,18}")

result = my_pattern.fullmatch(user_password)

print(result)











