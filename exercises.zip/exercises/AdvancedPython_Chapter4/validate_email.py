import re
user_email = 'jason.momoa@'
my_pattern = re.compile(r"(^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$)")

result = my_pattern.search(user_email)

print(result)











